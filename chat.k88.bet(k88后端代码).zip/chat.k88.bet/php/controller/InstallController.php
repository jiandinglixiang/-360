<?php
class InstallController extends Controller {
	protected $extensions = array('PDO', 'pdo_mysql');
	protected $writableFiles = array('data' => 'dir', 'upload' => 'dir', 'php/config/app.settings.php' => 'file', 'php/config/parameters.php' => 'file', 'php/config/widget.blacklist.txt' => 'file');
	protected $writableFilesForVerify = array('php/config/parameters.php' => 'file');
	protected $memoryServices = array('memory', 'memory.talks_map', 'memory.watched_talks', 'memory.stats', 'memory.online', 'memory.msg_q');
	public function indexAction() {
		return $this->render('admin/install.html');
	}
	public function verifyAction() {
		return $this->render('admin/install-verify.html', array('config' => $this->get('config')->data, 'trans' => json_encode($this->getJsTranslations())));
	}
	public function verifySubmitAction() {
		$spdb509c = $this->get('request');
		$spd40d27 = $this->get('verify');
		$sp479479 = $spdb509c->postVar('config');
		$sp1cf959 = $sp479479['services']['verify']['code'];
		$spa89a73 = $sp479479['services']['verify']['token'];
		$spd3147e = array();
		foreach ($this->writableFilesForVerify as $spbb3712 => $spf15dd1) {
			if (!is_writable(ROOT_DIR . '/../' . $spbb3712)) {
				$spd3147e[$spbb3712] = $spf15dd1;
			}
		}
		if (!empty($spd3147e)) {
			return $this->render('admin/install-verify.html', array('config' => $this->get('config')->data, 'notWritable' => $spd3147e, 'trans' => json_encode($this->getJsTranslations())));
		}
		if ($spd40d27->verifyCodeToken($sp1cf959, $spa89a73)) {
			$spd40d27->updateInstallation($sp1cf959, $spa89a73);
			return $this->redirect('Install:wizard');
		}
		return $this->redirect('Install:verify');
	}
	public function wizardAction() {
		ini_set('opcache.enable', 0);
		if (!$this->get('verify')->verifyInstallation()) {
			return $this->redirect('Install:verify');
		}
		$sp864e8d = $this->get('config')->data;
		return $this->render('admin/install-wizard.html', array('config' => $sp864e8d));
	}
	public function wizard2Action() {
		$spdb509c = $this->get('request');
		$sp7ce42b = $this->get('config');
		$sp864e8d = $spdb509c->postVar('config');
		$sp4b7bdb = $this->ensureValidConfig();
		if (!empty($sp4b7bdb)) {
			return $sp4b7bdb;
		}
		$sp5415f3 = array();
		foreach ($this->extensions as $spe2f6a9) {
			if (!extension_loaded($spe2f6a9)) {
				$sp5415f3[] = $spe2f6a9;
			}
		}
		if (!empty($sp5415f3)) {
			return $this->render('admin/install-wizard.html', array('config' => $sp864e8d, 'missingExtensions' => $sp5415f3));
		}
		$spd3147e = array();
		foreach ($this->writableFiles as $spbb3712 => $spf15dd1) {
			if (!is_writable(ROOT_DIR . '/../' . $spbb3712)) {
				$spd3147e[$spbb3712] = $spf15dd1;
			}
		}
		if (!empty($spd3147e)) {
			return $this->render('admin/install-wizard.html', array('config' => $sp864e8d, 'notWritable' => $spd3147e));
		}
		if (!$this->createMemoryFiles()) {
			return $this->render('admin/install-wizard.html', array('config' => $sp864e8d, 'notWritable' => array('data' => 'dir')));
		}
		$sp819635 = false;
		$sp6bad27 = $sp7ce42b->data['dbType'] . ':host=' . $sp864e8d['dbHost'] . ';port=' . $sp864e8d['dbPort'];
		try {
			$sp7ce42b->data['appSettings']['installed'] = false;
			if (!$this->get('db')->connect($sp6bad27, $sp864e8d['dbUser'], $sp864e8d['dbPassword'])) {
				$sp819635 = true;
			}
		}
		catch(Exception $sp8506e3) {
			$sp819635 = true;
		}
		if ($sp819635) {
			return $this->render('admin/install-wizard.html', array('config' => $sp864e8d, 'dbError' => $sp819635));
		}
		return $this->render('admin/install-wizard-2.html', array('config' => $sp864e8d));
	}
	public function wizard3Action() {
		$spdb509c = $this->get('request');
		$sp7ce42b = $this->get('config');
		$sp864e8d = $spdb509c->postVar('config');
		$sp4b7bdb = $this->ensureValidConfig();
		if (!empty($sp4b7bdb)) {
			return $sp4b7bdb;
		}
		unset($sp864e8d['superPassRepeat']);
		$spa43ea5 = $this->get('config');
		$spa43ea5->updateParameters($sp864e8d);
		$spa43ea5->updateAppSettings($sp864e8d['appSettings']);
		ini_set('opcache.enable', 0);
		$spa43ea5->onRegister();
		$sp6177e4 = $this->install();
		if (!$sp6177e4['success']) {
			$spa27c41 = true;
			$sp65f2db = $sp6177e4['message'];
			return $this->render('admin/install-wizard.html', array('config' => $sp864e8d, 'dbCreateError' => $spa27c41, 'message' => $sp65f2db));
		}
		$sp894d86 = $this->get('model_validation')->validateDb();
		if (count($sp894d86) !== 0) {
			$spa27c41 = true;
			$sp65f2db = $sp894d86['message'];
			return $this->render('admin/install-wizard.html', array('config' => $sp864e8d, 'dbCreateError' => $spa27c41, 'message' => $sp65f2db));
		}
		$this->get('logger')->info('Application installed');
		return $this->render('admin/install-wizard-3.html');
	}
	public function uninstallAction() {
		return $this->render('admin/uninstall.html');
	}
	public function uninstall2Action() {
		$spdb509c = $this->get('request');
		if (!$spdb509c->isPost()) {
			return $this->redirect('Install:uninstall');
		}
		$sp6177e4 = $this->uninstall();
		if (!$sp6177e4['success']) {
			$sp158f4b = true;
			$spa2e057 = $sp6177e4['errorMsg'];
			return $this->render('admin/uninstall.html', array('error' => $sp158f4b, 'errorMsg' => $spa2e057));
		}
		$this->get('logger')->info('Application uninstalled');
		return $this->render('admin/uninstall-2.html');
	}
	protected function createMemoryFiles() {
		$sp6177e4 = true;
		foreach ($this->memoryServices as $sp994cd2) {
			if (!touch($this->get($sp994cd2)->getFilePath())) {
				$sp6177e4 = false;
			}
		}
		return $sp6177e4;
	}
	protected function ensureValidConfig() {
		$spdb509c = $this->get('request');
		if ($spdb509c->isPost()) {
			$sp864e8d = $spdb509c->postVar('config');
			$spb5faaa = $this->get('model_validation');
			$sp894d86 = $spb5faaa->validateInstallConfig($sp864e8d);
			if (count($sp894d86) !== 0) {
				return $this->render('admin/install-wizard.html', array('config' => $sp864e8d, 'errors' => $sp894d86));
			}
		} else {
			return $this->redirect('Install:wizard');
		}
		return null;
	}
	protected function install() {
		$spb71ce9 = array('message' => '');
		if ($this->get('request')->isPost()) {
			$sp864e8d = $this->get('config');
			try {
				$sp9cc7c1 = file_get_contents(ROOT_DIR . '/../sql/install_' . $sp864e8d->data['dbType'] . '.sql');
				$sp9cc7c1 = str_replace('%db_name%', $sp864e8d->data['dbName'], $sp9cc7c1);
				$sp864e8d->data['appSettings']['installed'] = false;
				$spb71ce9['success'] = $this->get('db')->execute($sp9cc7c1);
			}
			catch(Exception $sp022b1a) {
				$spb71ce9['success'] = false;
				$spb71ce9['message'] = $sp022b1a->getMessage();
			}
			if ($spb71ce9['success']) {
				$sp864e8d->updateAppSettings(array('installed' => true));
				$spb71ce9 = $this->createAdmin($sp864e8d);
				if ($spb71ce9['success']) {
					$sp1bbd81 = $spb71ce9['admin'];
					$this->get('auth')->setUser($sp1bbd81->id, $sp1bbd81->name, $sp1bbd81->roles);
				}
			} else {
				if (empty($spb71ce9['message'])) {
					$spb71ce9['message'] = $this->get('i18n')->trans('other.error');
				}
			}
		}
		return $spb71ce9;
	}
	protected function createAdmin($sp864e8d) {
		$spb71ce9 = array('message' => '');
		$this->get('db')->reconnect();
		$sp1bbd81 = UserModel::repo()->findOneBy(array('roles' => array('Like', '%ADMIN%')));
		if (!$sp1bbd81) {
			$sp1bbd81 = new UserModel(array('roles' => array('ADMIN', 'OPERATOR'), 'info' => array('ip' => $this->get('request')->getIp())));
		}
		$sp1bbd81->name = $sp864e8d->data['superUser'];
		$sp1bbd81->mail = $sp864e8d->data['superUser'];
		$sp1bbd81->password = $this->get('security')->encodePassword($sp864e8d->data['superPass']);
		if ($sp1bbd81->save()) {
			$spb71ce9['success'] = true;
			$spb71ce9['admin'] = $sp1bbd81;
		} else {
			$spb71ce9['success'] = false;
			$spb71ce9['message'] = $this->get('i18n')->trans('admin.update.error');
		}
		return $spb71ce9;
	}
	protected function uninstall() {
		$spb71ce9 = array();
		if ($this->get('request')->isPost()) {
			$sp864e8d = $this->get('config');
			try {
				$sp9cc7c1 = file_get_contents(ROOT_DIR . '/../sql/uninstall_' . $sp864e8d->data['dbType'] . '.sql');
				$sp9cc7c1 = str_replace('%db_name%', $sp864e8d->data['dbName'], $sp9cc7c1);
				$spb71ce9['success'] = $this->get('db')->execute($sp9cc7c1);
			}
			catch(Exception $sp022b1a) {
				$spb71ce9['success'] = false;
				$spb71ce9['errorMsg'] = $sp022b1a->getMessage();
			}
			if ($spb71ce9['success']) {
				$sp9a62e3 = array('id' => '-1', 'name' => $sp864e8d->data['superUser'], 'roles' => array('ADMIN'));
				$this->get('auth')->setUser($sp9a62e3['id'], $sp9a62e3['name'], $sp9a62e3['roles']);
				$sp864e8d = $this->get('config');
				$sp864e8d->updateAppSettings(array('installed' => false));
				$sp864e8d->updateParameters(array('superPass' => ''));
			} else {
				$spb71ce9['error'] = $spb71ce9['errorMsg'] = $this->get('i18n')->trans('uninstall.error');
			}
		}
		return $spb71ce9;
	}
	protected function getJsTranslations() {
		$sp57b69a = $this->get('i18n');
		return array('connection.error' => $sp57b69a->trans('connection.error'), 'invalid.code.format' => $sp57b69a->trans('invalid.code.format'), 'invalid.purchase' => $sp57b69a->trans('invalid.purchase'));
	}
}
