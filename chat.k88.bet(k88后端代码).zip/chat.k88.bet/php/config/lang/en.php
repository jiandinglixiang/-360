<?php

return array(

    // Widget

    'loadingLabel'           => '加载中...',
    'loginError'             => '登录错误',
    'chatHeader'             => '在线咨询',
    'startInfo'              => '请填写联系方式就可以聊天了',
    'selectDepartment'       => '请选择部门',
    'selectCancel'           => '取消',
    'startLabel'             => '开始',
    'backLabel'              => '返回',
    'initMessageBody'        => '您好，请问有什么能帮到您的吗？',
    'initMessageAuthor'      => '在线客服',
    'chatInputLabel'         => '输入你的问题',
    'timeDaysAgo'            => '天前',
    'timeHoursAgo'           => '小时前',
    'timeMinutesAgo'         => '分钟前',
    'timeSecondsAgo'         => '秒钟前',
    'offlineMessage'         => '客服目前不在线',
    'toggleSoundLabel'       => '声音提醒',
    'toggleScrollLabel'      => '自动滚屏',
    'toggleEmoticonsLabel'   => '使用表情',
    'toggleMediaLabel'       => '使用媒体',
    'toggleAutoShowLabel'    => '自动显示',
    'toggleFullscreenLabel'  => '全屏切换',
    'endChatLabel'           => '结束聊天',
    'endChatConfirmQuestion' => '你确定当前操作?',
    'endChatConfirm'         => '是',
    'endChatCancel'          => '取消',
    'operatorClosedTalk'     => '客服已经结束了聊天对话',
    'loginAgain'             => '重新登录',
    'contactHeader'          => '离线留言',
    'contactInfo'            => '当前客服未在线，请提交留言，客服收到后会及时与您取得联系.',
    'contactNameLabel'       => '您的姓名',
    'contactMailLabel'       => '您的 e-mail',
    'contactQuestionLabel'   => '您的问题',
    'contactSendLabel'       => '发送',
    'contactSuccessHeader'   => '消息已发送',
    'contactSuccessMessage'  => '您的消息已经发送!',
    'contactErrorHeader'     => '出错啦',
    'contactErrorMessage'    => '发送过程中出现了点问题',
    'file.canceled'          => '已取消',
    'file.error'             => '错误',
    'file.denied'            => '拒绝',
    'file.too.big'           => '最大上传尺寸: %max% MB',
    'you'                    => '你自己',

    // Administration side

    'app.name' => 'PHP在线客服系统',

    'login.title' => '登录',
    'login.intro' => '填写好表单就可以登录在线客服平台了',
    'login.error' => '错误的用户名或者是密码错误',
    'login' => '登录',
    'your.mail' => '用户名',
    'your.pass' => '您的密码',
    'your.msg' => '填写您的信息',
    'welcome' => '欢迎使用',
    'edit.profile' => '编辑配置文件',
    'edit.operator' => '编辑操作者',
    'add.new.msg' => '添加新信息',
    'add.new.operator' => '添加新的操作者',
    'add.new.dep' => '添加新部门',
    'incorrect.install' => '错误的安装',
    'please.install' => '请先安装',
    'not.installed.msg' => '该应用程序尚未安装，请登录管理员并在使用前安装它',
    'install' => '安装',
    'edit.config' => '编辑配置',
    'uninstall' => '卸载',
    'qr.code' => '二维码',
    'qr.code.info' => '移动应用程序可以扫描以下二维码，方便地连接到该服务器。',
    'qr.code.note' => "不要使用通用的二维码扫描程序来扫描代码。请下载并安装PHP实时聊天移动应用程序。",
    'logs' => '日志',
    'widget.preview' => '聊天工具预览',
    'widget.get' => '生成聊天工具脚本',
    'logout' => '注销',
    'online.users' => '在线用户',
    'online.operators' => '在线客服',
    'user.info' => '用户信息',
    'visitor.invite' => '访客邀请',
    'invite.visitor.q' => '邀请访客交谈?',
    'invite' => '邀请',
    'settings' => '设置',
    'departments' => '部门',
    'operators' => '在线客服',
    'widget.settings' => '聊天设置',
    'widget.theme' => '聊天主题',
    'canned.messages' => '留言',
    'widget.blacklist' => '聊天黑名单',
    'history' => '历史记录',
    'primary.color' => '主题色调',
    'secondary.color' => '合成色',
    'label.color' => '标签颜色',
    'contact.mail' => '通过电子邮件联系',
    'hide.offline' => '离线时隐藏',
    'show.widget.auto' => '自动显示聊天窗口',
    'every.refresh' => '在每个页面刷新',
    'first.visit' => '只在第一次访问',
    'until.hide' => '在用户隐藏聊天窗口之前',
    'allow' => '允许',
    'turn.off' => '关闭',
    'show.widget.after' => '在多少秒后显示聊天窗口',
    'ask.mail' => '请求客人发电子邮件',
    'media.in.chat' => '媒体在聊天框(图片、视频)',
    'display.auto' => '自动展示',
    'display.clicked' => '点击之后显示',
    'chat.header' => '聊天抬头',
    'welcome.msg' => '欢迎标语',
    'msg.sound' => '新消息的声音',
    'sys.msg.sound' => '系统消息的声音',
    'shared.max.size' => '最大上传文件尺寸 (MB)',
    'file.sharing' => '文件共享',
    'gmaps.key' => 'Google Maps API key',
    'widget.width' => "聊天窗口的宽度(以像素为单位，最小为370)",
    'widget.height' => "聊天的高度(以像素为单位)",
    'widget.side' => "聊天窗口的侧边",
    'left' => '左边',
    'right' => '右边',
    'widget.offset' => "聊天窗口的偏移量(以像素为单位)",
    'mobile.bp' => '移动版的断点',
    'operator.init.chat' => '客服——启动聊天',
    'online.track.int' => '用户跟踪刷新率(s)',
    'max.conn' => '最大连接数',
    'poll.interval' => '聊天刷新频率(s)',
    'save' => '保持',
    'reset.to.def' => '重置为默认值',
    'departments' => '部门',
    'add.new' => '添加新的',
    'edit.department' => '编辑部门',
    'back.to.list' => '返回列表形式',
    'name' => '部门名称',
    'description' => '描述',
    'edit.op' => '编辑客服',
    'user.name' => '用户名',
    'mail' => '电子邮件',
    'user' => '用户名',
    'pass' => '密码',
    'retype.pass' => '重新输入密码',
    'avatar' => '头像',
    'from.coll' => '从收藏...',
    'curr.pass' => '当前密码',
    'new.pass' => '新的密码',
    'retype.new.pass' => '再次输入新密码',
    'change.pass' => '改变密码',
    'cancel' => '取消',
    'canned.msgs' => '留言信息',
    'edit.msg' => '编辑信息',
    'body' => '正文',
    'placeholder.hint' => 'You can use <i>{name}</i> and <i>{mail}</i> placeholders',
    'pages.no.widget' => '聊天窗口不应该显示的页面:',
    'no.widget.hint' => '(define each URL or part of the URL as a separate line, you can also use regular expressions, e. g. <i>/test\.html$/</i>)',
    'search' => '搜索',
    'clear.history' => '清除历史记录',
    'clear.history.q' => '你确定你想要清除所有的信息吗?',
    'clear.messages' => '清除信息',
    'participants' => '参与者',
    'refresh' => '刷新',
    'open.in.n.w' => '新窗口打开',
    'clear' => '清除',
    'from.date' => 'From date',
    'to.date' => 'To date',
    'uninstall.title' => '卸装',
    'uninstall.success' => '应用程序已成功卸载，数据库表被删除。但是，数据库本身仍然存在(如果需要的话，您可能需要手动删除它)。',
    'admin.panel' => '管理面板',
    'uninstall.intro' => "这是卸载页面。 如果您不想再使用这个应用程序, 
                请点击<i>卸载</i> 按钮.

                <br><br>

                卸载意味着操作员账户,消息历史和罐装的消息将被删除。
				管理员账户, 然而,仍将是可用的,你可以稍后再登录。
				数据库表将被删除,但数据库 本身仍然存在(您可能需要手动删除它,如果需要的话)。

                <br><br>

                <strong>
                    卸载过程完成后，所有应用程序的数据(操作符、消息历史、罐头消息)都将丢失。
                    如果需要，在卸载之前，您可以使用您喜欢的数据库管理工具(例如<i>phpMyAdmin</i>)备份应用程序数据库表。
                </strong>",
    'uninstall.err' => '在卸载过程中出现了一些问题。从数据库返回的错误消息是:',
    'widget.test' => '聊天窗口测试',
    'install.title' => '配置',
    'install.intro' => "欢迎使用 %app%. 您需要了解以下信息，如果不清楚请咨询空间服务商:

                <br><br>

                1. 数据库服务器地址 <br>
                2. 数据库端口 <br>
                3. 数据库名 <br>
                4. 数据库用户名 <br>
                5. 数据库密码

                <br><br>

                <strong>
                    如果没有数据库请用类似 <i>phpMyAdmin</i>的数据库管理软件建立一个
                </strong>",
    'lets.go' => "开始安装!",
    'wizard.2.title' => '安装',
    'wizard.2.intro' => '请检查给定的设置是否正确？如果没有错误请点击<i>安装</i>。',
    'db.settings' => '数据库设置',
    'host' => '主机',
    'port' => '端口',
    'db.name' => '数据库名称',
    'smtp' => 'SMTP',
    'use.smtp' => 'Use SMTP',
    'encryption' => '加密',
    'hosts' => 'Host(s)',
    'hosts.i' => 'Host(s), separate with ;',
    'admin.acc.settings' => '管理员帐户设置',
    'other.settings' => '其他设置',
    'back' => '返回',
    'wizard.verify.intro' => '在继续安装之前，请填写以下表格并填写您的购买代码。您可以按照下面的说明找到您的购买代码:',
    'verify.find.code' => '我的购买代码在哪里',
    'verify.info' => '安装数据表',
    'connection.error' => '连接错误',
    'invalid.code.format' => '代码格式不正确',
    'invalid.purchase' => '代码无效或属于其他项目',
    'install.not.verified' => '安装没有通过验证',
    'purchase.code' => '购买代码',
    'purchase.code.original' => '购买代码(原始)',
    'purchase.code.upgrade' => '购买代码(升级)',
    'wizard.3.title' => '安装完成',
    'wizard.3.success' => '安装已成功完成！现在可以进入管理面板了。',

    'wizard.intro' => "以下设置是整个应用程序的基本配置。
    它们用于与数据库通信并定义管理员用户的帐户。
    请填写表单,并点击<i>保存</i>按钮继续。

    <br><br>

    <strong>
        如果给定的数据库不存在,安装向导会自动为你创建它。 
        然而在某些服务器上这些操作是不允许的。但是请不要担心 —— 您可以使用您熟悉的数据库管理工具(例如<i>phpMyAdmin</i>) 手动创建这个数据库
		，创建完之后再返回到这个页面

        <br><br>

        如果你已经安装了这个应用程序,只是想改变一些设置, 您可以随意更新这些值并单击<i>保持</i> (现有数据库将保持安全且未受影响)。
    </strong>",
    'wizard.input.err' => '您的输入数据似乎是无效的，请检查下面的错误消息并更新表单。',
    'wizard.files.err' => '该应用程序要求一些文件可由PHP编写。以下是目前不可写的:',
    'wizard.files.err.2' => '请更新那些文件/目录的权限，让它们可以写出来，在完成之后再回来。',
    'wizard.ext.err' => '这个应用程序需要一些PHP扩展。以下扩展目前缺失:',
    'wizard.ext.err.2' => "请启用前面提到的扩展，并在完成后返回
        <br>
        (如果你不知道怎么做，请联系你的服务器供应商)。",
    'wizard.err.db' => "应用程序无法连接到给定的数据库。<br>
        请在数据库设置中检查所有的值，并确保您的数据库正在运行。",
    'wizard.err.db.2' => "尝试创建数据库和表失败。<br>
        请仔细检查所有在 <i>数据库设置</i>中的参数。

        <br><br>

        如果您的数据库 — %dbName% — 还没有创建请创建先
        手动创建数据库使用您最熟悉的数据库工具 (例如 <i>phpMyAdmin</i>) 创建好之后再返回到这个页面。

        <br><br>

        内部错误消息: %message% ?>",
    'smtp.intro' => 'Php Live Chat 允许您使用外部SMTP服务器来发送电子邮件。您可以将SMTP设置保留为使用默认的电子邮件服务器。',
    'pass.repeat' => '重复密码',
    'value.blank' => '值是空白的',
    'value.not.num' => '值不是一个数字类型',
    'value.not.mail' => '不是一个有效的电子邮件',
    'value.too.short' => '值太短了',
    'value.n.in.range' => '值超出允许范围',
    'values.not.match' => '值不匹配',
    'value.invalid' => '无效的值',
    'db.invalid' => '数据库结构是无效的',
    'db.exception' => '数据库异常: %msg%',
    'db.tables.invalid' => '无效的表结构, 实际表: %actual% 预计表: %expected%',
    'guest.watching' => 'Guest is watching',
    'unknown' => '未知',
    'invite.user' => '邀请用户',
    'leave.talk' => '离开会话',
    'canned' => '留言',
    'confirm.install' => '确认安装应用程序',
    'installation.invalid' => "安装似乎是无效的。
                <br><br>
                配置设置是不正确的或者你的数据库存在问题。
                <br><br>
                请仔细检查应用程序的设置。",
    'delete.user.q' => '你确定要永久删除这个用户吗?',
    'bottom.right.c' => '右下角',
    'inline' => '在线',
    'no.entries' => '部门还未创建，目前不能选择部门',
    'select.all' => '全部选择',
    'select.none' => '取消选择',
    'close.talk.msg' => "你现在是这次谈话的主人。你需要把它转移到另一个
                <br>
                操作人员是否应该继续。否则的话，你就可以结束谈话了.
                <br><br>
                选择客服的谈话:",
    'talk' => '谈话',
    'user.alrdy.in.t' => '用户已经在讨论中了',
    'talk.not.exist' => '谈话不存在',
    'user.not.exist' => '用户不存在',
    'cant.leave.unhandled.t' => "不能留下不被任何人处理的谈话",
    'only.t.owner.can.close' => "只有对话的所有者才能关闭它",
    'only.t.owner.can.transfer' => "只有说话的所有者才可以转让",
    'curr.pass.incorrect' => '密码:当前密码是不正确的',
    'user.not.found' => '用户不存在',
    'couldnt.save.user' => "不能保存用户",
    'display.more' => '显示更多',
    'id' => 'ID',
    'ip' => 'IP',
    'show.on.map' => '在地图中显示',
    'map.no.api.key.info' => '在“设置”选项卡中输入您的Google Maps API键并刷新页面。',
    'url' => 'URL',
    'browser' => '浏览器',
    'system' => '系统',
    'country' => '国家',
    'region' => '地区',
    'city' => '城市',
    'zip.code' => '邮政编码',
    'time.zone' => '时区',
    'local.time' => '当地时间',
    'latitude' => '纬度',
    'longitude' => '经线',
    'contact.form.mail' => '联系方式电子邮件',
    'sent.from.page' => '从页面发送',
    'author.name' => "作者的姓名",
    'author.mail' => "作者的电子邮件",
    'author.ip' => "作者的 IP",
    'message' => '通知',
    'contact.mail.note' => '你可以直接回复这封邮件来回答这个问题。',
    'route.not.found' => '路线没有找到',
    'route.not.found.msg' => '这个 <b>/%route%</b> 路径不存在。',
    'login.here' => '试着在这里登录',
    'error' => '错误',
    'sth.went.wrong.msg' => "好像出了问题。
            <br><br>
            尽管出了点差错但是请不要担心 — 下面这些错误信息能够帮助您找到问题的所在:",

    'db.error' => '数据库错误',
    'db.error.msg' => "应用程序无法连接到您的数据库。请确保数据库设置是正确的。

                    <br><br>

                    <strong>
                        如果您的数据库 — %dbName% — 还不存在，请创建它
                        手动使用您最喜欢的数据库管理工具 (e. g. <i>phpMyAdmin</i>) 创建完成后再再回来.
                    </strong>

                    <br><br>

                    从数据库返回的错误消息是:",
    'sign.as.admin' => '请以管理员身份登录并纠正数据库错误的设置',
    'uninstall.error' => '在卸载过程中出现了一个错误',
    'other.error' => '其它错误',
    'admin.update.error' => '错误更新管理员用户',
    'error.saving.file' => '保存文件有一个错误',
    'form.error' => '表单错误',
    'remove.msg' => '删除 "%message%"',
    'remove.msg.q' => '你确定你想永久删除这条信息吗?',
    'new.talk' => '新的谈话',
    'cant.chat.w.self' => "你不能和自己聊天",
    'select.msg' => '选择消息',
    'select.operator' => '选择客服',
    'invitation' => '邀请',
    'leave.talk.q' => '你确定你要结束这个对话吗?',
    'leave.talk.confirm' => '是的,离开对话',
    'transfer.n.leave' => '移交并离开',
    'end.talk' => '结束对话',
    'transfer' => '移交',
    'leave' => '离开',
    'remove.dep' => '删除 "%department%"',
    'remove.dep.q' => '你确定你想永久删除这个部门吗?',
    'clear.history.err' => '错误清理历史',
    'history.cleared' => '消息历史记录清除',
    'clear.logs' => '清除日志',
    'clear.logs.q' => '你确定你想要清除所有的日志?',
    'logs.cleared' => '清除所有日志',
    'clear.logs.err' => '错误清除日志',
    'widget.embd.code' => '聊天窗口嵌入代码',
    'uploading' => '上传',
    'uploading.image' => '上传图片,请等待...',
    'avatar.uploaded' => '头像上传',
    'uploaded.success' => '上传成功',
    'remove.user' => '删除 "%user%"',
    'remove.user.q' => '你确定你想永久删除这个用户吗?',
    'select.avatar' => '选择头像',
    'reset.settings' => '重置设置',
    'reset.settings.q' => '你确定要重置所有设置吗?',
    'reset' => '重置',
    'alert' => '人名',
    'v.cant.be.empty' => '值不能为空',
    'pass.have.to.match' => '密码必须匹配',
    'enter.valid.mail' => '请输入有效的电子邮件地址',
    'pass.need.6.chars' => '密码必须至少有6个字符长',
    'close' => '关闭',
    'language' => '语言',
    'default.language' => '默认的语言',

    // System messages

    'sm.closed.talk' => '%user% 已经结束了谈话',
    'sm.user.closed.chat' => '用户关闭了聊天窗口',
    'sm.now.talk.owner' => '%user% 现在是在和自己聊天',
    'sm.user.invited' => '%name% (%mail%) 已经被邀请交谈',
    'sm.user.left' => '%name% (%mail%) 已经离开了谈话'
);

?>
