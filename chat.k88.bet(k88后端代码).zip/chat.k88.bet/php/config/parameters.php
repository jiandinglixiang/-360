<?php

return array (
  'dbHost' => '127.0.0.1',
  'dbPort' => '3306',
  'dbUser' => 'k88chat',
  'dbPassword' => '5WcmaJnWJepys4JE',
  'dbName' => 'k88chat',
  'superUser' => 'admin',
  'superPass' => '123123',
  'services' => 
  array (
    'mailer' => 
    array (
      'smtp' => '',
      'smtpSecure' => 'ssl',
      'smtpHost' => '',
      'smtpPort' => '465',
      'smtpUser' => '',
      'smtpPass' => '',
    ),
  ),
  'appSettings' => 
  array (
    'contactMail' => 'admin@domain.com',
  ),
);

?>